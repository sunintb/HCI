# Team Members
## CS 67/267 - Introduction to HCI (Winter 2022) 
## High(er) Fidelty Prototype

GitHub usernames for each team member:

P4 Report Link: https://docs.google.com/document/d/1SsZpFOThES1WLQfYiiWv0bVwv_cn_qWrQ3aj25gsmGY/edit?usp=sharing 

Our interactive prototype features some of core functionality, specifically the onboarding and profile customization components. It has been built using React Native. 

Mid-Fidelity and High-Fidelity Figma Mockups can be found here: https://www.figma.com/file/atQrNcOxK1Cpm9nEA5q742/HCI%3A-Group-14-Prototype?node-id=0%3A1

Demo of the functional prototype can be found in the updateOnboarding.mp4 video.